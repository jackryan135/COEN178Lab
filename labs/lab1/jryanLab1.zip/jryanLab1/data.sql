INSERT INTO test VALUES(10, 'ten');
INSERT INTO test VALUES(11, 'eleven');
INSERT INTO test VALUES(12, 'twelve');
INSERT INTO test VALUES(13, 'thirteen');
